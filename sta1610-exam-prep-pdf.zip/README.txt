STA1610 Exam Prep — revision guide
=================================

Contents
  sta1610-exam-prep.pdf   116-page print-ready revision guide (A4)
  sta1610-exam-prep.html  the interactive single-file site

About the PDF
  - Cover page with an at-a-glance index, then a clickable contents page
    and 155 PDF bookmarks, so any heading is one click away.
  - Every worked solution is printed in full: nothing is behind a toggle.
  - Interactive furniture (search, timer, buttons) is removed, and the
    calculators are reduced to their inputs and formula.
  - LaTeX is typeset properly: real fractions, Greek letters, super- and
    subscripts (xbar, sigma-squared, square roots).
  - Callouts are tinted boxes with a coloured rule; tables repeat their
    header row when they cross a page.
  - Running header, page numbers, and a formula sheet at the end that can
    be printed on its own.

Chapters
    01  What is Statistics?
    02  Types of Data
    03  Sampling Methods
    04  Frequency Distributions & Tables
    05  Measures of Central Tendency
    06  Measures of Dispersion
    07  Measures of Position & Box Plots
    08  Probability Basics
    09  Probability Rules
    10  Bayes' Theorem
    23  Discrete Random Variables
    11  The Binomial Distribution
    12  The Poisson Distribution
    13  The Normal Distribution
    14  Sampling Distributions & the Central Limit Theorem
    15  Confidence Intervals
    16  Hypothesis Testing Framework
    17  Z-Test for the Population Mean
    18  T-Test for the Population Mean
    19  Z-Test for a Population Proportion
    20  Chi-Square Tests
    21  Correlation
    22  Simple Linear Regression
  CALC  Interactive Calculators
  FORMULAS  Complete Formula Sheet

Suggested use
  Print double-sided on A4. Work the exam-prep chapter first, then use the
  paper references (for example "2024 Q19, p.10") to revise weak topics.
  Keep the last few pages — the formula sheet — for the final hour.

The PDF was generated from the HTML by tools/build_pdf.py, so it can be
rebuilt after any content edit:  python3 tools/build_pdf.py
