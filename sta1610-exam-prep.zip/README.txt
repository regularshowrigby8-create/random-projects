STA1610 Exam Prep — improved single-file site
=============================================

Contents
  sta1610-exam-prep.html   the whole site: 23 topic guides, exam-prep section,
                           calculators, formula sheet, light/dark themes.

How to open
  Double-click the .html file, or drag it into any browser. No server,
  no build step, no install. Works offline after the first load; the only
  external resources are Google Fonts and KaTeX (from a CDN).

What is new in this version
  - fixed layout: calculator and formula-sheet styles were missing entirely
  - new three-column shell: grouped sidebar, sticky top bar, section rail
  - light + dark theme, remembered between visits
  - scroll reveals, page transitions, card spotlight, hover depth
  - prev/next topic pager, quick find (/ or Ctrl+K), keyboard shortcuts
  - progress ring, reading bar, "continue where you left off"
  - print stylesheet that prints all notes cleanly

Progress, revision ticks and the theme live in your browser's local storage;
nothing is sent anywhere.
